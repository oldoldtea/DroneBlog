# DroneBlog MCP Server 使用指南

## 打包

### 方式一：Wheel 包（推荐）

```bash
cd droneblog_mcp
python -m build
```

输出：
- `dist/droneblog_mcp-0.1.0-py3-none-any.whl` — 可直接安装的 wheel 包
- `dist/droneblog_mcp-0.1.0.tar.gz` — 源码分发包

### 方式二：本地开发模式

```bash
cd droneblog_mcp
pip install -e .
```

## 安装

### 方式一：pip 安装 wheel 包

```bash
pip install droneblog_mcp-0.1.0-py3-none-any.whl
```

### 方式二：从源码安装

```bash
git clone https://github.com/oldoldtea/droneblog-mcp.git
cd droneblog-mcp
pip install -e .
```

### 方式三：uv 安装（快速）

```bash
uv pip install droneblog_mcp-0.1.0-py3-none-any.whl
```

## 配置

### 环境变量

```bash
export DRONEBLOG_DIR=/path/to/your/blog      # 博客工作目录（必需）
export OPENAI_API_KEY=sk-...                 # OpenAI API Key（必需，用于 AI 生成）
export DRONEBLOG_MODEL=gpt-4o-mini           # 默认 AI 模型（可选）
export DRONEBLOG_TEMPERATURE=0.7             # 生成温度（可选）
export DRONEBLOG_MAX_TOKENS=4000             # 最大 token 数（可选）
export DRONEBLOG_AUTO_CONFIRM=false          # 是否跳过人工审核（可选，默认 false）
```

### MCP 客户端配置（Claude Desktop）

编辑配置文件：
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **Linux**: `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "droneblog": {
      "command": "python3",
      "args": ["-m", "droneblog_mcp"],
      "env": {
        "DRONEBLOG_DIR": "/home/lz/workspace/personal/my_blog",
        "OPENAI_API_KEY": "sk-..."
      }
    }
  }
}
```

## 命令行使用

### 查看版本

```bash
droneblog-mcp version
```

### 查看状态

```bash
# 使用环境变量指定博客目录
export DRONEBLOG_DIR=/path/to/blog
droneblog-mcp status

# 或临时指定
DRONEBLOG_DIR=/path/to/blog droneblog-mcp status
```

### 启动 MCP Server

```bash
# stdio 模式（默认，用于 MCP 客户端如 Claude Desktop）
droneblog-mcp serve

# SSE 模式（HTTP 接口）
droneblog-mcp serve --transport sse

# 指定博客目录
droneblog-mcp serve --dir /path/to/blog
```

## 可用 Tools（11 个）

| Tool | 功能 | 示例参数 |
|------|------|----------|
| `blog_generate` | 生成博客文章 | `{"topic": "C++20 协程", "category": "系统编程", "tags": ["C++", "协程", "异步编程"]}` |
| `blog_list` | 列出文章 | `{"category": "后端开发", "limit": 10}` |
| `blog_read` | 读取文章 | `{"slug": "tokio-async-runtime"}` |
| `blog_edit` | 编辑文章 | `{"slug": "xxx", "title": "新标题", "tags": ["新标签1", "新标签2"]}` |
| `blog_delete` | 删除文章 | `{"slug": "xxx", "confirm": true}` |
| `config_get` | 获取配置 | `{"scope": "site"}` |
| `config_set` | 修改配置 | `{"scope": "site", "key": "title", "value": "新标题"}` |
| `build` | 构建站点 | `{}` |
| `deploy` | 部署站点 | `{"build_first": true}` |
| `pipeline_status` | 查看流水线状态 | `{}` |
| `pipeline_run` | 执行完整流水线 | `{"task_type": "debug_build", "params": {}}` |

## 可用 Resources（5 个）

| Resource | 内容 |
|----------|------|
| `blog://{slug}` | 单篇文章 Markdown 内容 |
| `blog://list` | 文章列表 |
| `config://site` | 站点配置 YAML |
| `config://theme` | 主题配置 YAML |
| `pipeline://log` | 流水线日志 |

## 可用 Prompts（3 个）

| Prompt | 用途 |
|--------|------|
| `blog_writing` | 博客写作助手 |
| `tech_analysis` | 技术文章分析 |
| `blog_idea_generator` | 博客选题生成 |

## 使用示例

### 生成文章

```
User: 帮我写一篇关于 "C++20 协程" 的博客文章，分类到系统编程，标签是 C++、协程、异步编程

Claude: [调用 blog_generate 工具]

文章已生成！文件路径: source/_posts/cpp20-coroutines.md
标题: C++20 协程深度解析
分类: 系统编程
标签: C++, 协程, 异步编程
已通过 6 阶段流水线验证，构建成功。
```

### 列出文章

```
User: 列出我最近写的关于 Kafka 的文章

Claude: [调用 blog_list 工具，筛选 tag=Kafka]

找到 2 篇文章:
1. kafka-message-transmission (Kafka 消息传输机制)
2. kafka-source-analysis (Kafka 源码解析)
```

### 构建部署

```
User: 构建并部署站点

Claude: [调用 build 工具，然后调用 deploy 工具]

构建成功！public/ 目录已生成。
部署成功！已推送到 oldoldtea.github.io 的 master 分支。
```

## 项目结构

```
droneblog_mcp/
├── pyproject.toml              # 项目配置
├── README.md
├── src/
│   └── droneblog_mcp/
│       ├── __init__.py
│       ├── __main__.py         # CLI 入口
│       ├── server.py           # MCP Server 主类
│       ├── tools/
│       │   ├── blog.py         # 文章相关工具
│       │   ├── config.py       # 配置相关工具
│       │   ├── build.py        # 构建部署工具
│       │   └── pipeline.py     # 流水线工具
│       ├── core/
│       │   ├── pipeline.py     # 流水线执行器
│       │   └── generator.py    # AI 内容生成器
│       ├── models/
│       │   ├── config.py       # Pydantic 配置模型
│       │   └── blog.py         # 博客数据模型
│       └── utils/
│           ├── fs.py           # 文件系统操作
│           ├── yaml.py         # YAML 处理
│           └── log.py          # 日志工具
├── dist/                       # 构建输出
│   ├── droneblog_mcp-0.1.0-py3-none-any.whl
│   └── droneblog_mcp-0.1.0.tar.gz
└── tests/                      # 测试目录
```

## 流水线阶段

```
[需求分析] → [Skill 识别] → [AI 生成] → [人工审核] → [合规审核] → [安全审查] → [构建验证] → [输出]
```

## 注意事项

1. **Python 版本**: 需要 Python 3.11+
2. **Hexo 依赖**: 博客目录必须包含有效的 Hexo 项目（`_config.yml`、`source/_posts/` 等）
3. **OpenAI API Key**: 只有 `blog_generate` 和 `pipeline_run` 的 `content_creation` 任务需要
4. **人工审核**: 默认会打开编辑器让用户审核生成的文章，可通过 `auto_confirm=true` 跳过（仅用于自动化场景）
5. **Git 提交**: 部署前确保已配置 `hexo-deployer-git`
